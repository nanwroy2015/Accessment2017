Please following the following steps for implementation:

1. Create a folder named  'sampleData' under C:\

 2. Move all the following files to the folder created.
1) FormatSamples.xlsx
2) FormatStatus.xlsx
3) FormatUsers.xlsx
4) Samples.txt
5) Status.txt
6) Users.txt

Please make sure all the about files are under the path in C:\sampleData\


4. For the convenience of testing purpose, 

The progrm read data from the following files instead of DB tables. 
C:\sampleData\FormatSamples.xlsx
C:\sampleData\FormatStatus.xlsx
C:\sampleData\FormatUsers.xlsx

The progrm write new record created the following file to instead of DB tables.
c:\sampleData\Samples.txt

The new record created will be inserted to file c:\sampleData\Samples.txt.  ** Please check the new record created in this file. 
             
       
***Please make sure all these file exists in the right PATH as advised above.
***Note:I'd like to share the source files with Gene-by-Gene Inc. 
      Please do not share with any other 3rd party without my permission.