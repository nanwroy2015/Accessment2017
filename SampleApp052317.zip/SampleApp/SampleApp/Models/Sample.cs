﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.ComponentModel;
using System.Text;

namespace SampleApp.Models
{
    public class Sample
    {
        private int sampleID;
        private string barCode;
        private DateTime createdAt;
        private int createdBy;
        private int statusID;
        private string user;
        private string status;

        public Sample()
        {
           
        }        

        public Sample(int sampleID, string barCode, DateTime createdAt, int createdBy, int statusID, string user, string status)
        {
            // TODO: Complete member initialization
            this.sampleID = sampleID;
            this.barCode = barCode;
            this.createdAt = createdAt;
            this.createdBy = createdBy;
            this.statusID = statusID;
            this.user = user;
            this.status = status;
        }
        public int SampleID { get { return sampleID; } }
        public string BarCode { get { return barCode; } }
        public DateTime CreatedAt { get { return createdAt; } }
        public int CreatedBy { get { return createdBy; } }
        public int StatusID { get { return statusID; } }
        public string User { get { return user; } }
        public string Status { get { return status; } }
    }

}