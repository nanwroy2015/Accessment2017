For implementation:

1. Create a folder named  'sampleData' under C:\
 and move all the following files to the folder created.
1) FormatSamples.xlsx
2) FormatStatus.xlsx
3) FormatUsers.xlsx
4) Samples.txt
5) Status.txt
6) Users.txt

2. 
The progrm read data from:  
C:\sampleData\FormatSamples.xlsx
C:\sampleData\FormatStatus.xlsx
C:\sampleData\FormatUsers.xlsx

The progrm write new record created data to:
c:\sampleData\Samples.txt

***Please make sure all these file exists in the right PATH as advised above.

I'd like to share the source files with Gene-by-Gene Inc. Please do not share with other 3rd party without my permission.