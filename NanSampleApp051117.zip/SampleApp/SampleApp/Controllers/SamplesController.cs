﻿using SampleApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using System.Data.OleDb;
using System.ComponentModel;


namespace SampleApp.Controllers
{
    public class SamplesController : ApiController
    {
        DataTable dt4Sample = new DataTable();
        DataTable dt4Status = new DataTable();
        DataTable dt4Users = new DataTable();

        public string Inputfile4Sample = @"C:\sampleData\FormatSamples.xlsx";
        public string Inputfile4Status = @"C:\sampleData\FormatStatus.xlsx";
        public string Inputfile4Users = @"C:\sampleData\FormatUsers.xlsx";
        public List<Sample> objSample = new List<Sample>();
        

        public SamplesController()
        {
            dt4Sample = this.ReadExcelFile(Inputfile4Sample);
            DataTable tempDtSample = new DataTable();
            tempDtSample.Columns.Add("SampleID", typeof(int));
            tempDtSample.Columns.Add("BarCode", typeof(string));
            tempDtSample.Columns.Add("CreatedAt", typeof(DateTime));
            tempDtSample.Columns.Add("CreatedBy", typeof(int));
            tempDtSample.Columns.Add("StatusID", typeof(int));

            if (dt4Sample.Rows.Count > 0)
            {
                DataRow r1 = null;
                foreach (DataRow dr in dt4Sample.AsEnumerable())
                {
                    r1 = tempDtSample.NewRow();
                    r1["SampleID"] = dr["SampleID"];
                    r1["BarCode"] = dr["BarCode"];
                    r1["CreatedAt"] = dr["CreatedAt"];
                    r1["CreatedBy"] = dr["CreatedBy"];
                    r1["StatusID"] = dr["StatusID"];
                    tempDtSample.Rows.Add(r1);
                }
            }

            dt4Status = this.ReadExcelFile(Inputfile4Status);
            DataTable tempDtStatus = new DataTable();
            tempDtStatus.Columns.Add("StatusID", typeof(int));
            tempDtStatus.Columns.Add("Status", typeof(string));

            if (dt4Status.Rows.Count > 0)
            {
                DataRow r2 = null;
                foreach (DataRow dr in dt4Status.AsEnumerable())
                {
                    r2 = tempDtStatus.NewRow();
                    r2["StatusID"] = dr["StatusID"];
                    r2["Status"] = dr["Status"];
                    tempDtStatus.Rows.Add(r2);
                }
            }


            dt4Users = this.ReadExcelFile(Inputfile4Users);
            DataTable tempDtUsers = new DataTable();
            tempDtUsers.Columns.Add("UserId", typeof(int));
            tempDtUsers.Columns.Add("FirstName", typeof(string));
            tempDtUsers.Columns.Add("LastName", typeof(string));

            if (dt4Users.Rows.Count > 0)
            {
                DataRow r3 = null;
                foreach (DataRow dr in dt4Users.AsEnumerable())
                {
                    r3 = tempDtUsers.NewRow();
                    r3["UserId"] = dr["UserId"];
                    r3["FirstName"] = dr["FirstName"];
                    r3["LastName"] = dr["LastName"];
                    tempDtUsers.Rows.Add(r3);
                }
            }

            var results = from table1 in tempDtSample.AsEnumerable()
                          join table2 in tempDtStatus.AsEnumerable() on (int)table1["StatusId"]
                          equals (int)table2["StatusId"]
                          join table3 in tempDtUsers.AsEnumerable() on (int)table1["CreatedBy"]
                          equals (int)table3["UserId"]
                          select new Sample
                          (
                              (int)table1["SampleID"],
                              (string)table1["BarCode"],
                              (DateTime)table1["CreatedAt"],
                              (int)table1["CreatedBy"],
                              (int)table1["StatusId"],
                              (string)(table3["FirstName"]) + " " +(string)(table3["LastName"]),
                              (string)table2["Status"]

                          );
            this.objSample = results.ToList();
        }

       

      
        public IEnumerable<Sample> GetAllProducts()
        {
           return this.objSample;         
        }

        [ActionName("ApiById")]
        public IHttpActionResult GetProduct(int id)
        {
            var sample = this.objSample.FirstOrDefault((p) => p.SampleID == id);
            if (sample == null)
            {
                return NotFound();
            }
            return Ok(sample);
        }


        [HttpGet]
        public IHttpActionResult GetSampleByStatus(string text)
        {
            var sample = this.objSample.Where((p) => p.Status.ToLower() == text.ToLower()).ToList();
            if (sample == null || sample.Count == 0)
            {
                return NotFound();
            }
            return Ok(sample);
        }

        [HttpGet]       
        public IHttpActionResult GetSampleByUser(string text)
        {
            var sample = this.objSample.Where(p => (p.User.ToLower().Contains(text.ToLower()) == true)).ToList();
            if (sample == null || sample.Count == 0)
            {
                return NotFound();
            }
            return Ok(sample);
        }

        // SaveNewSample
        [HttpPost]
        public bool SaveNewSample([FromBody] dynamic data)
        {
            try
            {     // db.SaveChanges();
                Sample newSampleObj = new Sample();
                int tempStatusId = -1;
                int tempUserID = -1;
                  
                bool isValid = false;
                var tempList = this.objSample;
                var tempSampleID = tempList.Max(p => p.SampleID) + 1;              
                var tempBarCode = (data.BarCode ?? string.Empty).ToString();
                var inputStatus = (data.Status ?? string.Empty).ToString();
                var inputFirstName = (data.FirstName ?? string.Empty).ToString();
                var inputLastName  = (data.LastName ?? string.Empty).ToString();
                var inputUser = inputFirstName +" " + inputLastName;

                var CheckExistedUserID = tempList.Where(p => p.User.ToLower()
                                        == inputUser.ToLower()).ToList();

                var CheckExistedtatusID = tempList.Where(p => p.Status.ToLower()
                                        == inputStatus.ToLower()).ToList();
                var tempCreatdAt = DateTime.Now;

                if(CheckExistedUserID.Count > 0 && CheckExistedtatusID.Count > 0)
                    isValid = true;

                if (isValid)
                {
                    tempStatusId = Convert.ToInt32(CheckExistedtatusID.FirstOrDefault().StatusID.ToString());
                    tempUserID =  Convert.ToInt32(CheckExistedUserID.FirstOrDefault().CreatedBy.ToString());;
                    Sample obj = new Sample(tempSampleID, tempBarCode, tempCreatdAt, tempUserID, tempStatusId, inputUser, inputStatus);
                    this.objSample.Add(obj);
                    //Note:  In reality, insert new record 'obj' to DB table,
                    //For testing purpose, the new record will be inserted to file 'Samples.txt'
                    bool succeed = false;
                    string path4Sample = @"c:\sampleData\Samples.txt";
                    
                    if (File.Exists(path4Sample))
                    {
                        using (StreamWriter sw = File.AppendText(path4Sample))
                        {
                            sw.WriteLine(obj.SampleID + "," + obj.BarCode + "," + obj.CreatedAt.ToString("yyyy-MM-dd") + "," + obj.CreatedBy + "," + obj.StatusID + "\n");
                            succeed = true;
                        }
                    }

                    if(succeed)
                         return Request.CreateResponse(HttpStatusCode.OK).IsSuccessStatusCode;
                    else
                         return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Error").IsSuccessStatusCode;
                }

                else
                {
                   return Request.CreateResponse(HttpStatusCode.BadRequest).IsSuccessStatusCode;
                }

            }
            catch 
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Error").IsSuccessStatusCode;
            }
           
        }

     
        public string GetConnectionString(string fileName)
        {
            Dictionary<string, string> props = new Dictionary<string, string>();

            // XLSX - Excel 2007, 2010, 2012, 2013
            props["Provider"] = "Microsoft.ACE.OLEDB.12.0;";
            props["Extended Properties"] = "Excel 12.0 XML";

            string path = Directory.GetCurrentDirectory();
            props["Data Source"] = fileName;

            StringBuilder sb = new StringBuilder();

            foreach (KeyValuePair<string, string> prop in props)
            {
                sb.Append(prop.Key);
                sb.Append('=');
                sb.Append(prop.Value);
                sb.Append(';');
            }

            return sb.ToString();
        }

        public DataTable ReadExcelFile(string fileName)
        {
              DataSet ds = new DataSet();
              DataTable dt = new DataTable();
              
             string connectionString = GetConnectionString(fileName);

                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = conn;

                    // Get all Sheets in Excel File
                    DataTable dtSheet = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    // Loop through all Sheets to get data
                    foreach (DataRow dr in dtSheet.Rows)
                    {
                        string sheetName = dr["TABLE_NAME"].ToString();


                        if (!sheetName.EndsWith("$"))
                            continue;

                        // Get all rows from the Sheet
                        cmd.CommandText = "SELECT * FROM [" + sheetName + "]";


                        dt.TableName = sheetName;

                        OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                        da.Fill(dt);                       
                    }

                    cmd = null;
                    conn.Close();
                }
           
            return dt;
        }
       
    }

   
}
